import numpy as np

notas = np.array([float(input(f"Informe a nota do {i+1}º aluno: ")) for i in range(15)])

media = np.mean(notas)
print("A média desses alunos foi de:", media)
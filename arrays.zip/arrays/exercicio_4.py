import numpy as np

vetor = np.array([int(input(f"Digite o {i+1}º número: ")) for i in range(8)])

X = int(input("Digite o índice X (0 a 7): "))
Y = int(input("Digite o índice Y (0 a 7): "))

if 0 <= X < 8 and 0 <= Y < 8:
    soma = vetor[X] + vetor[Y]
    print(f"A soma dos valores nas posições {X} e {Y} é: {soma}")
else:
    print("Índices inválidos. Por favor, forneça índices entre 0 e 7.")

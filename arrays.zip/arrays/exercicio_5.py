import numpy as np

vetor = np.array([int(input(f"Digite o {i+1}º número: ")) for i in range(10)])

valores_pares = np.sum(vetor % 2 == 0)

print(f"O vetor possui {valores_pares} valores pares.")

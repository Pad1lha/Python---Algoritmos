import numpy as np

numeros = []

for i in range(10):
    while True:
        try:
            num = float(input(f"Digite o {i + 1}º número real: "))
            numeros.append(num)
            break
        except ValueError:
            print("Entrada inválida. Por favor, insira um número real.")

array_numeros = np.array(numeros)

quantidade_negativos = np.sum(array_numeros < 0)

soma_positivos = np.sum(array_numeros[array_numeros > 0])

print(f"Quantidade de números negativos: {quantidade_negativos}")
print(f"Soma dos números positivos: {soma_positivos}")

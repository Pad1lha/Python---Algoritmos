import numpy as np

array = np

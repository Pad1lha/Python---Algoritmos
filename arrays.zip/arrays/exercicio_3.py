import numpy as np

numeros_reais = np.array([float(input(f"Digite o {i+1}º número real: ")) for i in range(10)])

quadrados = np.square(numeros_reais)

print("\nVetor com os números reais:")
print(numeros_reais)

print("\nVetor com os quadrados dos números:")
print(quadrados)

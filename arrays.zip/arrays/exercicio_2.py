import numpy as np

lista = np.zeros(6)
for x in range(6):
    lista[x] = int(input("Insira um numero: "))

print(lista)
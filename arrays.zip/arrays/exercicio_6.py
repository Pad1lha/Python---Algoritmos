import numpy as np

valores = np.array([int(input(f"Digite o {i+1}º número: ")) for i in range(10)])

print("A maior posição é:", max(valores))
print("A menor posição é:", min(valores))

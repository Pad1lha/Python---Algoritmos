import numpy as np

vetor = np.array([int(input(f"Digite o {i+1}º número inteiro: ")) for i in range(10)])

maior_elemento = np.max(vetor)

posicao_maior = np.argmax(vetor)

print("O vetor é:", vetor)

print(f"O maior elemento é {maior_elemento}, encontrado na posição {posicao_maior}.")

import numpy as np

A = np.array([1, 0, 5, -2, -5, 7])
soma = A[0] + A[1] + A[5]
print(soma)
A[4] = 100
print(A[4])

print(A[0]) 
print(A[1]) 
print(A[2]) 
print(A[3]) 
print(A[4]) 
print(A[5]) 
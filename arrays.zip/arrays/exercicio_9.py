import numpy as np

numeros_pares = []

for i in range(6):
    while True:
        try:
            num = int(input(f"Digite o {i + 1}º número par: "))
            if num % 2 == 0:
                numeros_pares.append(num)
                break
            else:
                print("O número não é par. Tente novamente.")
        except ValueError:
            print("Entrada inválida. Por favor, insira um número inteiro.")

array_pares = np.array(numeros_pares)

array_invertido = np.flip(array_pares)

print("Números pares na ordem inversa:")
print(array_invertido)
